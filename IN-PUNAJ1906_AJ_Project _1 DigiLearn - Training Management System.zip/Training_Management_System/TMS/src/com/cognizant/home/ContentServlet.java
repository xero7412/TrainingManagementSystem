package com.cognizant.home;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.dao.ContentDao;
import com.cognizant.daoimpl.ContentDaoImpl;
import com.cognizant.model.Content;


@WebServlet("/ContentServlet")
public class ContentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ContentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		int i=0;
		int j=0;
	
		
		String m_ccode=request.getParameter("ccode");
		String m_topic=request.getParameter("topic");
		String m_data=request.getParameter("data");
		Content content =new Content(m_ccode,m_topic,m_data);
		
		/*HttpSession session=request.getSession();
		ArrayList<Content> al=(ArrayList<Content>) session.getAttribute("clist");
		for(Content c:al){
			out.println(c.getCoursecode()+" "+c.getData()+" "+c.getTopic());
		}*/        
		HttpSession session=request.getSession();
		String name=(String)session.getAttribute("name");
		ArrayList<Content> al=(ArrayList<Content>) session.getAttribute("clist");
		System.out.println(name);
		ContentDao cDao=new ContentDaoImpl();
		for(Content con:al)
		{
			
			if(cDao.insertContent(con))
		{
			//response.sendRedirect("content.jsp");
			System.out.println("Inserted");
			i++;
			
		}
	
		}	
		j = al.size();
		if(i==j){
			
			response.sendRedirect("questionsadd.jsp");
		}
		
	}

}


/*

if(m_topic.equals("null"))
	{
session.setAttribute("clist", cList);
	} 
*/