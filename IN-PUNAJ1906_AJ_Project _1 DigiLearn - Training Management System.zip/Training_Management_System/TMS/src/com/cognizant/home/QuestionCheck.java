package com.cognizant.home;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.dao.QuestionsDao;
import com.cognizant.daoimpl.QuestionDaoImpl;

/**
 * Servlet implementation class QuestionCheck
 */
@WebServlet("/QuestionCheck")
public class QuestionCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

   /* 
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    	super.service(arg0, arg1);
		  String method= arg0.getMethod();
		  if(method.equals("GET"))
		  {
			  doPost(arg0, arg1);
			  
		  }
		
	}*/


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		QuestionsDao qDao=new QuestionDaoImpl();
		
		ArrayList<String> qnoList=(ArrayList<String>) session.getAttribute("qnolist");
		ArrayList<String> rListOption=(ArrayList<String>) session.getAttribute("rlistoption");
				
		String ccode=(String)session.getAttribute("code");
		String rightOption=null;
		
		int score=0;
		
		Iterator qitr=qnoList.iterator();
		Iterator ritr=rListOption.iterator();
		String q=null,rl=null;
		while(qitr.hasNext()&&(ritr.hasNext()))
		{
			q=(String) qitr.next();
			rl=(String) ritr.next();
			rightOption=qDao.rightOption(q,ccode);
			System.out.println("pichewaala"+rl);
			System.out.println("finalwaala"+rightOption);
			
			if(rl.equalsIgnoreCase(rightOption))
			{
				score+=10;
				System.out.println("right");
			}
			else if(rl.equals("null"))
			{
				System.out.println(" ");
			}
			else {
				System.out.println("wrong") ;
			}
		}
		
		String sc=Integer.toString(score);
		session.setAttribute("score", sc);
		response.sendRedirect("scoreadd.jsp");
	}

	
}

