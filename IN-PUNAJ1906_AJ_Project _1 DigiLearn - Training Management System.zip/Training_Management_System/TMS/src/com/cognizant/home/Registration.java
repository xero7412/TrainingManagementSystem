package com.cognizant.home;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.RegistrationDao;
import com.cognizant.daoimpl.RegistrationDaoimpl;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Registration() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
        String m_firstname = request.getParameter("fname");
        String m_lastname = request.getParameter("lname");
        String m_age = request.getParameter("age");
        String m_gender= request.getParameter("gender");
        String m_cnumber = request.getParameter("cno");
        String m_userid = request.getParameter("uid");
        String m_password = request.getParameter("pass");
        String m_email = request.getParameter("email");
        String m_usertype = request.getParameter("utype");
     
        RegistrationDao rService=new RegistrationDaoimpl();
        /*System.out.println( m_firstname +" "+ m_lastname +" "+m_age+" "+  m_gender+" "+ m_cnumber +" "+  m_userid +" "+
                m_password+" "+ m_email+" "+m_usertype );*/
        com.cognizant.model.Registration rModel=new com.cognizant.model.Registration(m_firstname,m_lastname,Integer.parseInt(m_age),m_gender, m_cnumber, m_userid, m_password, m_email, m_usertype);
        if(rService.validate(rModel))
        {
        	System.out.println("Validated");
        	/*System.out.println("validated inside if");*/
        	if(rService.insert(rModel))
            {
                /*out.println( m_firstname +" "+ m_lastname +" "+m_age+" "+  m_gender+" "+ m_cnumber +" "+  m_userid +" "+
                        m_password+" "+ m_email+" "+m_usertype );*/
        			System.out.println("Record Inserted");
        			response.sendRedirect("Login.jsp");
        			
            }
            else
            {
            	System.out.println("Error not inserted");
            	response.sendRedirect("registration.html");
            }
        }  else
        {
        	System.out.println("Error not validated");
        	response.sendRedirect("registration.html");
        }
        
	}

}
