package com.cognizant.home;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.dao.RegistrationDao;
import com.cognizant.daoimpl.RegistrationDaoimpl;

@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginPage() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String m_userid = request.getParameter("u_id");
		String m_password = request.getParameter("u_pass");
		String m_usertype = request.getParameter("u_type");
		HttpSession session=request.getSession();
		RegistrationDao rService=new RegistrationDaoimpl();
		if(m_usertype.equals("A"))
		{
			if(rService.validateLogin(m_userid, m_password, m_usertype))
			{ 
				String m_name=rService.getName(m_userid);
				response.sendRedirect("AdminPage.jsp");
				session.setAttribute("name", m_name);
			}
			else response.sendRedirect("Login.jsp");
		}
		else if(m_usertype.equals("U"))
			{
			if(rService.validateLogin(m_userid, m_password, m_usertype))
			{ 	
				String m_name=rService.getName(m_userid);
				response.sendRedirect("userview.jsp");
				session.setAttribute("name", m_name);
			}
		else
		{
			response.sendRedirect("Login.jsp");
		}
	 
	
	}
}
}