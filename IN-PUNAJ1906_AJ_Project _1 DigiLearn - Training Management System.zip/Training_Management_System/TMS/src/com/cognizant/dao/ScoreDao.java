package com.cognizant.dao;

import com.cognizant.model.Score;

public interface ScoreDao {

	boolean addScore(Score score);
	Score calculateScore(String ccode,String userid);
	
}
