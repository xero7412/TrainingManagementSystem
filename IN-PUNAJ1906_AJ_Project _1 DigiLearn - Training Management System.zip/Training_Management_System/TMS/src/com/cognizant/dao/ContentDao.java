package com.cognizant.dao;

import java.util.ArrayList;

import com.cognizant.model.Content;

public interface ContentDao {

	boolean insertContent(Content content);
	boolean deleteContent(String ccode);
	ArrayList<String> viewTopic(String ccode);
	String viewData(String ccode,String topic);
	int status(String ccode);
}
