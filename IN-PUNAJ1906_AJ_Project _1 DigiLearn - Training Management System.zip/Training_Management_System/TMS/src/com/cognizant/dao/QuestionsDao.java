package com.cognizant.dao;

import java.util.ArrayList;

import com.cognizant.model.Questions;

public interface QuestionsDao {

	boolean addQuestions(Questions questions);
	Questions viewQuestions(String ccode,int qno);
	String rightOption(String qno,String ccode);
}
