package com.cognizant.dao;

import java.util.ArrayList;

import com.cognizant.model.Course;

public interface CourseDao {

	public boolean insertCourse(Course course);
	
	public ArrayList<Course> viewCourse();
	public boolean updateCourse(String courseCode,String courseDesc,String skills,String courseDate,String courseTime);
	public boolean deleteCourse(String courseCode);
	public ArrayList<Course> userViewCourse();
	public String courseDescription(String courseCode);
	public ArrayList<Course> searchCourse(String courseName);
	
}
