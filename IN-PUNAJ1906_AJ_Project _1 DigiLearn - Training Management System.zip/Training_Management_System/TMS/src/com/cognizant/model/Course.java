package com.cognizant.model;

public class Course {

	private String courseCode;
	private String courseName;
	private String courseDesc;
	private String skills;
	private String courseDate;
	private String courseTime;
	private String addedBy;
	
	
	public Course() {
		super();
	}


	public Course(String courseCode, String courseName, String courseDesc, String skills, String courseDate,
			String courseTime, String addedBy) {
		super();
		this.courseCode = courseCode;
		this.courseName = courseName;
		this.courseDesc = courseDesc;
		this.skills = skills;
		this.courseDate = courseDate;
		this.courseTime = courseTime;
		this.addedBy = addedBy;
	}

	public Course(String courseCode, String courseName, String skills, String courseDate,
			String courseTime, String addedBy) {
		super();
		this.courseCode = courseCode;
		this.courseName = courseName;
		
		this.skills = skills;
		this.courseDate = courseDate;
		this.courseTime = courseTime;
		this.addedBy = addedBy;
	}

	public String getCourseCode() {
		return courseCode;
	}


	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public String getCourseDesc() {
		return courseDesc;
	}


	public void setCourseDesc(String courseDesc) {
		this.courseDesc = courseDesc;
	}


	public String getSkills() {
		return skills;
	}


	public void setSkills(String skills) {
		this.skills = skills;
	}


	public String getCourseDate() {
		return courseDate;
	}


	public void setCourseDate(String courseDate) {
		this.courseDate = courseDate;
	}


	public String getCourseTime() {
		return courseTime;
	}


	public void setCourseTime(String courseTime) {
		this.courseTime = courseTime;
	}


	public String getAddedBy() {
		return addedBy;
	}


	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}


	
	
	
	
	
}
