package com.cognizant.model;

public class Content {

	private String coursecode;
	private String topic;
	private String data;
	public Content() {
		super();
	}
	public Content(String coursecode, String topic, String data) {
		super();
		this.coursecode = coursecode;
		this.topic = topic;
		this.data = data;
	}
	public String getCoursecode() {
		return coursecode;
	}
	public void setCoursecode(String coursecode) {
		this.coursecode = coursecode;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	
}
