package com.cognizant.model;

public class Score {

	private String userId;
	private String ccode;
	private String score;
	public Score(String userId, String ccode, String score) {
		super();
		this.userId = userId;
		this.ccode = ccode;
		this.score = score;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	

}
