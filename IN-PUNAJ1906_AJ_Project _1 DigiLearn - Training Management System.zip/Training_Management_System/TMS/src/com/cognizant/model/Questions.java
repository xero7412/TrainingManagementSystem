package com.cognizant.model;

public class Questions {

	private String qno;
	private String courseCode;
	private String qdesc;
	private String option1;
	private String option2;
	private String option3;
	private String option4;
	private String rightOption;
	
	
	
	public Questions() {
		super();
	}
	
	
	




	public Questions(String qno, String courseCode, String qdesc, String option1, String option2, String option3,
			String option4, String rightOption) {
		super();
		this.qno = qno;
		this.courseCode = courseCode;
		this.qdesc = qdesc;
		this.option1 = option1;
		this.option2 = option2;
		this.option3 = option3;
		this.option4 = option4;
		this.rightOption = rightOption;
	}







	public String getQno() {
		return qno;
	}
	public void setQno(String qno) {
		this.qno = qno;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
	public String getQdesc() {
		return qdesc;
	}
	public void setQdesc(String qdesc) {
		this.qdesc = qdesc;
	}
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	public String getOption2() {
		return option2;
	}
	public void setOption2(String option2) {
		this.option2 = option2;
	}
	public String getOption3() {
		return option3;
	}
	public void setOption3(String option3) {
		this.option3 = option3;
	}
	public String getOption4() {
		return option4;
	}
	public void setOption4(String option4) {
		this.option4 = option4;
	}
	public String getRightOption() {
		return rightOption;
	}
	public void setRightOption(String rightOption) {
		this.rightOption = rightOption;
	}
	
	
	
}
