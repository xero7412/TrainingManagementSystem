package com.cognizant.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cogni.util.JdbcConnection;
import com.cognizant.dao.RegistrationDao;
import com.cognizant.model.Registration;

public class RegistrationDaoimpl implements RegistrationDao {

	public boolean insert(Registration registration) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into user_details values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, registration.getFirstName());
			pst.setString(2, registration.getLastName());
			pst.setInt(3, registration.getAge());
			pst.setString(4, registration.getGender());
			pst.setString(5, registration.getContactNo());
			pst.setString(6, registration.getUserId());
			pst.setString(7,registration.getPassword());
			pst.setString(8, registration.getEmail());
			pst.setString(9, registration.getUserType());
			int flag=pst.executeUpdate();
			if(flag==1)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return false;
	}
	
	public Registration getUser(String userid)
	{
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from user_details where userid=?";

		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, userid);
			ResultSet rs=pst.executeQuery();
			Registration reg=null;
			if(rs.next())
			{
				String v_fistname=rs.getString(1);
				String v_lastname=rs.getString(2);
				int v_age=rs.getInt(3);
				String v_gender=rs.getString(4);
				String v_contactno=rs.getString(5);
				String v_userid=rs.getString(6);
				String v_password=rs.getString(7);
				String v_email=rs.getString(8);
				String v_usertype=rs.getString(9);
				reg=new Registration(v_fistname, v_lastname, v_age, v_gender, v_contactno, v_userid, v_password, v_email, v_usertype);
				return reg;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public boolean update(Registration reg) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="update set firstname=?,lastname=?,age=?,contactnumber=?,password=?,email=?,usertype=? from user_details where userid=?";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, reg.getFirstName());
			pst.setString(2, reg.getLastName());
			pst.setInt(3, reg.getAge());
			pst.setString(4, reg.getContactNo());
			pst.setString(5,reg.getPassword());
			pst.setString(6, reg.getEmail());
			pst.setString(7, reg.getUserType());
			pst.setString(8, reg.getUserId());
			int rec=pst.executeUpdate();
			if(rec==1)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return false;
	}

	@Override
	public boolean validate(Registration registration) {
		/*System.out.println(registration.getUserType());*/
		boolean x=registration.getUserId().matches("[A][D][M][0-9]{3}");
		/*System.out.println(x);*/
		if((registration.getUserType()).equals("A") && x==true)
		{
			return true;
		}
		else if (registration.getUserType().equals("U")) {
			return true;
		}
		else{
		return false;}
	}

	@Override
	public boolean validateLogin(String user_id, String password, String user_type) {
		Connection con=null;
		con=JdbcConnection.getConnection();
		String userid=null;
		String pass=null;
		
		String query="select userid, password from user_details where userid=? and usertype=?";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, user_id);
			pst.setString(2, user_type);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				userid=rs.getString(1);
				pass=rs.getString(2);
				
			}
			if(userid.equals(user_id)&&pass.equals(password))
			{
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		return false;
	}

	@Override
	public String getName(String m_userid) {
		Connection con=null;
		con=JdbcConnection.getConnection();
		String m_fname=null;
		String m_lname=null;
		String query="select firstname, lastname from user_details where userid=?";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, m_userid);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				m_fname=rs.getString(1);
				m_lname=rs.getString(2);
				String m_fullname=m_fname+" "+m_lname;
				return m_fullname;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return null;
	}
	
	
/*	//validation
public boolean validateLogin(Registration registration) {
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		con=JdbcConnection.getConnection();
		
		String query="select * from login where username=? and password=?";
		try {
			pst=con.prepareStatement(query);
			pst.setString(1,registration.getUserId());
			pst.setString(2, registration.getUserType());
			
			rs=pst.executeQuery();
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(rs!=null)
			{		try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			if(pst!=null)
			{
				try {
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		return false;
	}*/
	
	
}
