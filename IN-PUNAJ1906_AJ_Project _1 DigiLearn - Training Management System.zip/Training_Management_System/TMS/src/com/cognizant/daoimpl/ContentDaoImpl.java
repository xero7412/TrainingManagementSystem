package com.cognizant.daoimpl;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cognizant.dao.ContentDao;
import com.cognizant.model.Content;
import com.cogni.util.JdbcConnection;

public class ContentDaoImpl implements ContentDao{

	@Override
	public boolean insertContent(Content content) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into content values(?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, content.getCoursecode());
			pst.setString(2, content.getTopic());
			pst.setString(3, content.getData());
			int rec=pst.executeUpdate();
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
			if(rec==1)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return false;
	}
	public boolean deleteContent(String ccode) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="delete from content where course_code=?";
		
		try {
			PreparedStatement ps=con.prepareStatement("commit");
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1,ccode);
			
			int rec=pst.executeUpdate();
			ps.executeUpdate();
			if(rec>=1)
			{
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		return false;
	}
	@Override
	public ArrayList<String> viewTopic(String ccode) {
		 Connection con = null;
         ArrayList<String> topicList=new ArrayList<>();
         String data = null;
        
         con = JdbcConnection.getConnection();
         String query = "select topic from content where course_code= ?";

         try {
                PreparedStatement pst = con.prepareStatement(query);

                pst.setString(1, ccode);

                ResultSet rs = pst.executeQuery();
                int i=0;
                while (rs.next()) {

                      topicList.add(rs.getString(1));
                }

         } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
         } finally {

                try {
                      con.close();
                } catch (SQLException e) {
                      // TODO Auto-generated catch block
                      e.printStackTrace();
                }

         }

		return topicList;
	}
	@Override
	public String viewData(String ccode, String topic) {
		
		Connection con = null;
      
        String data = null;


        con = JdbcConnection.getConnection();

        String query1 = "select data from content where topic=? and course_code= ?";

        try {

               PreparedStatement pst1 = con.prepareStatement(query1);

               pst1.setString(1, topic);
               pst1.setString(2, ccode);

               ResultSet rs1 = pst1.executeQuery();
               System.out.println("ssss");
               if (rs1.next()) {

                   data = rs1.getString(1);
               }

        } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        } finally {

               try {
                     con.close();
               } catch (SQLException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }

        }
		
		return data;
	}
	@Override
	public int status(String ccode) {
		
		int count=0;
		Connection con=null;
		PreparedStatement pst=null;
		try{
		con=JdbcConnection.getConnection();
		String query="select count(topic) from content1 where course_code=?";
		pst=con.prepareStatement(query);
		pst.setString(1, ccode); 
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
		      count=Integer.parseInt(rs.getString(1)); 
		      /* out.println(rs.getInt(1)); */
		      }
		}catch (SQLException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		}finally{
		      try {
		            con.close();
		      } catch (SQLException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		      }
		}
		
		return count;
	}
}
