package com.cognizant.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cogni.util.JdbcConnection;
import com.cognizant.dao.QuestionsDao;
import com.cognizant.model.Questions;

public class QuestionDaoImpl implements QuestionsDao{

	@Override
	public boolean addQuestions(Questions questions) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into questions values(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, questions.getQno());
			pst.setString(2, questions.getCourseCode());
			pst.setString(3, questions.getQdesc());
			pst.setString(4, questions.getOption1());
			pst.setString(5, questions.getOption2());
			pst.setString(6, questions.getOption3());
			pst.setString(7, questions.getOption4());
			pst.setString(8, questions.getRightOption());
			int rec=pst.executeUpdate();
			if(rec==1)
			{
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	@Override
	public Questions viewQuestions(String ccode,int qno) {
	
		Connection con = null;
      
        con = JdbcConnection.getConnection();
        String query = "select * from questions where course_code= ? and qno=? order by qno";
        Questions q=null;
        try {
               PreparedStatement pst = con.prepareStatement(query);
               String str=Integer.toString(qno);
               pst.setString(1, ccode);
               pst.setString(2, str);
               ResultSet rs = pst.executeQuery();
              
               String qdesc,option1,option2,option3,option4,rightOption;
               while (rs.next()) {

                     
                     ccode=rs.getString(2);
                     qdesc=rs.getString(3);
                     option1=rs.getString(4);
                     option2=rs.getString(5);
                     option3=rs.getString(6);
                     option4=rs.getString(7);
                     rightOption=rs.getString(8);
                     q=new Questions(str, ccode, qdesc, option1, option2, option3, option4, rightOption);
      
               }

        } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        } finally {

               try {
                     con.close();
               } catch (SQLException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }

        }

		return q;
		
	}

	@Override
	public String rightOption(String qno,String ccode) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select right_option from questions where qno=? and course_code=?";
		String ro=null;
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, qno);
			pst.setString(2, ccode);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ro=rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return ro;
	}
	

}
