package com.cognizant.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cogni.util.JdbcConnection;
import com.cognizant.dao.ScoreDao;
import com.cognizant.model.Questions;
import com.cognizant.model.Score;

public class ScoreDaoImpl implements ScoreDao{

	@Override
	public Score calculateScore(String ccode, String userid) {
		
		Connection con = null;
	      
        con = JdbcConnection.getConnection();
        String query = "select score from score where course_code= ? and user_name=?";
        Score sc=null;
        try {
               PreparedStatement pst = con.prepareStatement(query);
              
               pst.setString(1, ccode);
               pst.setString(2, userid);
               ResultSet rs = pst.executeQuery();
              
               String score=null;
               while (rs.next()) {

                     score=rs.getString(1);
                     
               }
               sc=new Score(userid,ccode,score);
               
        } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        } finally {

               try {
                     con.close();
               } catch (SQLException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
               }

        }

		return sc;
	}

	@Override
	public boolean addScore(Score score) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into score values(?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, score.getUserId());
			pst.setString(2, score.getCcode());
			
			pst.setString(3, score.getScore());
			int rec=pst.executeUpdate();
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
			if(rec==1)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	
		return false;
	}

}
