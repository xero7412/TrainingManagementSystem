package com.cognizant.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cognizant.model.Course;
import com.cognizant.dao.CourseDao;
import com.cogni.util.JdbcConnection;

public class CourseDaoImpl implements CourseDao{

	@Override
	public boolean insertCourse(Course course) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="insert into course values(?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, course.getCourseCode());
			pst.setString(2, course.getCourseName());
			pst.setString(3, course.getCourseDesc());
			pst.setString(4, course.getSkills());
			pst.setString(5, course.getCourseDate());
			pst.setString(6, course.getCourseTime());
			pst.setString(7, course.getAddedBy());
			int rec=pst.executeUpdate();
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
			if(rec==1)
			{
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	@Override
	public ArrayList<Course> viewCourse() {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="select * from course order by course_code";
		ArrayList<Course> cList=new ArrayList<>();
		try {
			PreparedStatement pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String ccode=rs.getString(1);				
				String cname=rs.getString(2);
				String cdesc=rs.getString(3);
				String cskills=rs.getString(4);
				String cdate=rs.getString(5);
				String ctime=rs.getString(6);
				String addedby=rs.getString(7);
				Course course=new Course(ccode, cname, cdesc, cskills, cdate, ctime, addedby);
				cList.add(course);
				
			}
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cList;
		
	}

	@Override
	public boolean updateCourse(String courseCode,String courseDesc,String skills,String courseDate,String courseTime) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="update course set course_desc=?,skills=?,course_date=?,course_time=? where course_code=?";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, courseDesc);
			pst.setString(2, skills);
			pst.setString(3, courseDate);
			pst.setString(4, courseTime);
			pst.setString(5, courseCode);
			int rec=pst.executeUpdate();
			if(rec==1)
			{
				return true;
			}
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean deleteCourse(String cCode) {
		
		Connection con=null;
		con=JdbcConnection.getConnection();
		String query="delete from course where course_code=? ";
		try {
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1,cCode);
			int rec=pst.executeUpdate();
			if(rec==1)
			{
				return true;
				
			}
			//String q="commit";
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		return false;
	}

	@Override
	public ArrayList<Course> userViewCourse() {
	
		 Connection con = null;

         con = JdbcConnection.getConnection();
         String query = "select course_code,course_name,skills,course_date,course_time,addedby from course";
         String ccode=null;
         ArrayList<Course> cList=new ArrayList<>();
         try {
                PreparedStatement pst = con.prepareStatement(query);
                ResultSet rs = pst.executeQuery();
                
                while (rs.next()) {

                       ccode = rs.getString(1);
                      String cname = rs.getString(2);
                      String skills=rs.getString(3);
                      String cdate = rs.getString(4);
                      String ctime = rs.getString(5);
                      String addedby = rs.getString(6);
                      
                      cList.add(new Course(ccode,cname,skills,cdate,ctime,addedby));
                }
              

         } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
         } finally {

                try {
                      con.close();
                } catch (SQLException e) {
                      // TODO Auto-generated catch block
                      e.printStackTrace();
                }
               
         }
         return cList;
	}

	@Override
	public String courseDescription(String courseCode) {
		Connection con = null;
	      
//	     /* String ccode1=(String)session.getAttribute("code");
//	     out.println(ccode1); */
	              con = JdbcConnection.getConnection();
	              String query = "select course_desc from course where course_code= ?";
	              String cdesc=null;
	              try {
	                     PreparedStatement pst = con.prepareStatement(query);
	                     pst.setString(1, courseCode);
	                     ResultSet rs = pst.executeQuery();
	                     
	                     while (rs.next()) {

	                           cdesc = rs.getString(1);
	                     }

	              } catch (SQLException e) {
	                     // TODO Auto-generated catch block
	                     e.printStackTrace();
	              } finally {

	                     try {
	                           con.close();
	                     } catch (SQLException e) {
	                           // TODO Auto-generated catch block
	                           e.printStackTrace();
	                     }

	              }

		return cdesc;
	}

	@Override
	public ArrayList<Course> searchCourse(String courseName) {
		Connection con = null;
		con=JdbcConnection.getConnection();
		
		              String query = "select course_code,course_name,skills,course_date,course_time,addedby from course where course_name=?";
		              ArrayList<Course> cList=new ArrayList<>();
		              try {
		                     PreparedStatement pst = con.prepareStatement(query);
		                     pst.setString(1, courseName);
		                     ResultSet rs = pst.executeQuery();

		                     while (rs.next()) {

		                    	 String ccode = rs.getString(1);
		                         String cname = rs.getString(2);
		                         String skills=rs.getString(3);
		                         String cdate = rs.getString(4);
		                         String ctime = rs.getString(5);
		                         String addedby = rs.getString(6);
		                         
		                         cList.add(new Course(ccode,cname,skills,cdate,ctime,addedby));
		                           

		                     }

		                     } catch (SQLException e) {
		                            // TODO Auto-generated catch block
		                            e.printStackTrace();
		                     } finally {

		                            try {
		                                  con.close();
		                            } catch (SQLException e) {
		                                  // TODO Auto-generated catch block
		                                  e.printStackTrace();
		                            }

		                     }
		return cList;
	}
	
	
}
	              

