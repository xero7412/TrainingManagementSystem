package com.cogni.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConnection {

	public static Connection getConnection(){
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@PC278254.cts.com:1521:xe";
		String user="HR";
		String password="hr";
		Connection con=null;
		
		try {
			con=DriverManager.getConnection(url,user,password);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return con;
		
	}


	public static Connection getConnection(String url){
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	
		String user="HR";
		String password="hr";
		Connection con=null;
		
		try {
			con=DriverManager.getConnection(url,user,password);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return con;
		
	}

}
